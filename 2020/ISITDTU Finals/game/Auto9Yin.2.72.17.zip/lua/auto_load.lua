function load_script( ... )
	nx_execute("auto\\form_qiyu_set", "load_core")
	nx_execute("form_auto_main", "load_core")
end