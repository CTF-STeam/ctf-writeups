require("qiyu_set")
function load_core( ... )
	local file = nx_resource_path() .. "auto9yin\\lua\\load_auto_core.lua"
	dofile(file)
end