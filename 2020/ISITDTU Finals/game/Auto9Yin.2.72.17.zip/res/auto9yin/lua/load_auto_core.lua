function utf8_to_widestr(content)
  return nx_function("ext_utf8_to_widestr", content)
end

function widestr_to_utf8(content)
  return nx_function("ext_widestr_to_utf8", content)
end

function copy_text( text )
  nx_function("ext_copy_wstr", nx_widestr(text))
end
require("auto_core")
load_auto_core()