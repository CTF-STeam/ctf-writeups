Must be valid path
preg_match("/^[a-z0-9.]$/", $_GET['page']);
