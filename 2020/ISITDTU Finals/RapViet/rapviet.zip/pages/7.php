
<div class="main-photobook-content-wrapper">
   <div class="photobook-picture">
      <a title="" href="https://2sao.vietnamnetjsc.vn/images/2020/10/14/13/32/boc-gia-do-huan-luyen-vien-rap-viet-18.jpg" data-med="https://2sao.vietnamnetjsc.vn/images/2020/10/14/13/32/boc-gia-do-huan-luyen-vien-rap-viet-18.jpg" data-size="600x600" data-med-size="600x600">
         <img src="https://2sao.vietnamnetjsc.vn/images/2020/10/14/13/32/boc-gia-do-huan-luyen-vien-rap-viet-18.jpg" alt="">  
         <span class="slider-image-captions">
            <span class="slider-image-captions-inner">
               <figure>
                  <p>Tạo hình của Karik ở tập mới nhất bị nói đùa giống nghệ sĩ Trung Dân. Nhưng ít ai biết phụ kiện nam rapper đeo của thương hiệu Chanel lên tới gần 80 triệu đồng cho dây chuyền và cài áo.</p>
               </figure>
            </span>
         </span>
      </a>
   </div>
   <div class="photobook-info-data-box">
      <div class="photobook-content-box">
         <div class="photobook-content-box-inner">
            <div class="photobook-content-box-wrapper">
               <p>Tạo hình của Karik ở tập mới nhất bị nói đùa giống nghệ sĩ Trung Dân. Nhưng ít ai biết phụ kiện nam rapper đeo của thương hiệu Chanel lên tới gần 80 triệu đồng cho dây chuyền và cài áo.</p>
            </div>
         </div>
      </div>
      <div class="photobook-line-bottom">
         <div class="photobook-line"><span>2sao.vn</span> | <span>Photobook</span></div>
      </div>
   </div>
</div>
