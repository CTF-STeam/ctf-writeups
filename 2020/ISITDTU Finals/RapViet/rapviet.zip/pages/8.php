
<div class="main-photobook-content-wrapper">
   <div class="photobook-picture">
      <a title="" href="https://2sao.vietnamnetjsc.vn/images/2020/10/14/13/46/boc-gia-do-huan-luyen-vien-rap-viet-4.jpg" data-med="https://2sao.vietnamnetjsc.vn/images/2020/10/14/13/46/boc-gia-do-huan-luyen-vien-rap-viet-4.jpg" data-size="600x600" data-med-size="600x600">
         <img src="https://2sao.vietnamnetjsc.vn/images/2020/10/14/13/46/boc-gia-do-huan-luyen-vien-rap-viet-4.jpg" alt="">  
         <span class="slider-image-captions">
            <span class="slider-image-captions-inner">
               <figure>
                  <p>Đắt giá nhất bộ trang phục của Wowy là sợi dây chuyền vàng 18k nặng 6 lượng, là tác phẩm nghệ thuật đương đại. Dù bao gồm dây và tượng đầu người nhưng Wowy đã cất tượng đi và chỉ đeo dây lên sân khấu. Nếu chỉ tính riêng tỷ giá về vàng thì tác phẩm này phải có giá trị tầm 350 triệu đồng.</p>
               </figure>
            </span>
         </span>
      </a>
   </div>
   <div class="photobook-info-data-box">
      <div class="photobook-content-box">
         <div class="photobook-content-box-inner">
            <div class="photobook-content-box-wrapper">
               <p>Đắt giá nhất bộ trang phục của Wowy là sợi dây chuyền vàng 18k nặng 6 lượng, là tác phẩm nghệ thuật đương đại. Dù bao gồm dây và tượng đầu người nhưng Wowy đã cất tượng đi và chỉ đeo dây lên sân khấu. Nếu chỉ tính riêng tỷ giá về vàng thì tác phẩm này phải có giá trị tầm 350 triệu đồng.</p>
            </div>
         </div>
      </div>
      <div class="photobook-line-bottom">
         <div class="photobook-line"><span>2sao.vn</span> | <span>Photobook</span></div>
      </div>
   </div>
</div>
