<div class="main-photobook-content-wrapper">
   <div class="photobook-picture">
      <a title="" href="https://2sao.vietnamnetjsc.vn/images/2020/10/14/13/32/boc-gia-do-huan-luyen-vien-rap-viet-14.jpg" data-med="https://2sao.vietnamnetjsc.vn/images/2020/10/14/13/32/boc-gia-do-huan-luyen-vien-rap-viet-14.jpg" data-size="600x600" data-med-size="600x600">
         <img src="https://2sao.vietnamnetjsc.vn/images/2020/10/14/13/32/boc-gia-do-huan-luyen-vien-rap-viet-14.jpg" alt="">  
         <span class="slider-image-captions">
            <span class="slider-image-captions-inner">
               <figure>
                  <p>Cả một cây đồ Gucci gồm áo và quần mới bằng tiền đôi giày Jordan 1 Retro High Off-White White. Thế mới thấy đồ đi ở dưới chân chưa chắc rẻ tiền.</p>
               </figure>
            </span>
         </span>
      </a>
   </div>
   <div class="photobook-info-data-box">
      <div class="photobook-content-box">
         <div class="photobook-content-box-inner">
            <div class="photobook-content-box-wrapper">
               <p>Cả một cây đồ Gucci gồm áo và quần mới bằng tiền đôi giày Jordan 1 Retro High Off-White White. Thế mới thấy đồ đi ở dưới chân chưa chắc rẻ tiền.</p>
            </div>
         </div>
      </div>
      <div class="photobook-line-bottom">
         <div class="photobook-line"><span>2sao.vn</span> | <span>Photobook</span></div>
      </div>
   </div>
</div>
