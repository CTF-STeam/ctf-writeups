
<div class="main-photobook-content-wrapper">
   <div class="photobook-picture">
      <a title="" href="https://2sao.vietnamnetjsc.vn/images/2020/10/14/13/46/boc-gia-do-huan-luyen-vien-rap-viet-3.jpg" data-med="https://2sao.vietnamnetjsc.vn/images/2020/10/14/13/46/boc-gia-do-huan-luyen-vien-rap-viet-3.jpg" data-size="600x600" data-med-size="600x600">
         <img src="https://2sao.vietnamnetjsc.vn/images/2020/10/14/13/46/boc-gia-do-huan-luyen-vien-rap-viet-3.jpg" alt="">  
         <span class="slider-image-captions">
            <span class="slider-image-captions-inner">
               <figure>
                  <p>Dân cư mạng đùa rằng do đưa tiền cho vợ mua đồ nên trang phục của JustaTee cũng rất bình dân.</p>
               </figure>
            </span>
         </span>
      </a>
   </div>
   <div class="photobook-info-data-box">
      <div class="photobook-content-box">
         <div class="photobook-content-box-inner">
            <div class="photobook-content-box-wrapper">
               <p>Dân cư mạng đùa rằng do đưa tiền cho vợ mua đồ nên trang phục của JustaTee cũng rất bình dân.</p>
            </div>
         </div>
      </div>
      <div class="photobook-line-bottom">
         <div class="photobook-line"><span>2sao.vn</span> | <span>Photobook</span></div>
      </div>
   </div>
</div>
