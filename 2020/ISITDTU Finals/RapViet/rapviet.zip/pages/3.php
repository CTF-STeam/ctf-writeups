<div class="main-photobook-content-wrapper">
   <div class="photobook-picture">
      <a title="" href="https://2sao.vietnamnetjsc.vn/images/2020/10/14/13/17/boc-gia-do-huan-luyen-vien-rap-viet-15.jpg" data-med="https://2sao.vietnamnetjsc.vn/images/2020/10/14/13/17/boc-gia-do-huan-luyen-vien-rap-viet-15.jpg" data-size="600x600" data-med-size="600x600">
         <img src="https://2sao.vietnamnetjsc.vn/images/2020/10/14/13/17/boc-gia-do-huan-luyen-vien-rap-viet-15.jpg" alt="">  
         <span class="slider-image-captions">
            <span class="slider-image-captions-inner">
               <figure>
                  <p>Trong vòng Bứt phá, stylist của Binz chia sẻ: "Trang phục được xây dựng để bổ trợ cho đồng hồ". Quả đúng thật mẫu Jacob &amp; Co Astronomia Solar Watch này có giá trị lên tới 281.000 USD. Khi quy đổi ra tiền Việt với 8 con số 0 khiến nhiều người hoa mắt.</p>
               </figure>
            </span>
         </span>
      </a>
   </div>
   <div class="photobook-info-data-box">
      <div class="photobook-content-box">
         <div class="photobook-content-box-inner">
            <div class="photobook-content-box-wrapper">
               <p>Trong vòng Bứt phá, stylist của Binz chia sẻ: "Trang phục được xây dựng để bổ trợ cho đồng hồ". Quả đúng thật mẫu Jacob &amp; Co Astronomia Solar Watch này có giá trị lên tới 281.000 USD. Khi quy đổi ra tiền Việt với 8 con số 0 khiến nhiều người hoa mắt.</p>
            </div>
         </div>
      </div>
      <div class="photobook-line-bottom">
         <div class="photobook-line"><span>2sao.vn</span> | <span>Photobook</span></div>
      </div>
   </div>
</div>
