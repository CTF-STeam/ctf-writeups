<div class="main-photobook-content-wrapper">
   <div class="photobook-picture">
      <a title="" href="https://2sao.vietnamnetjsc.vn/images/2020/10/14/13/32/boc-gia-do-huan-luyen-vien-rap-viet-8.jpg" data-med="https://2sao.vietnamnetjsc.vn/images/2020/10/14/13/32/boc-gia-do-huan-luyen-vien-rap-viet-8.jpg" data-size="600x600" data-med-size="600x600">
         <img src="https://2sao.vietnamnetjsc.vn/images/2020/10/14/13/32/boc-gia-do-huan-luyen-vien-rap-viet-8.jpg" alt="">  
         <span class="slider-image-captions">
            <span class="slider-image-captions-inner">
               <figure>
                  <p>Chiếc áo chỉ có 6 triệu nhưng phụ kiện cài áo thì có giá gấp 7 lần. Tuy nhiên vẫn không bằng việc Karik mua 2 đôi giày khác nhau và đi mỗi đôi 1 chiếc như vậy.</p>
               </figure>
            </span>
         </span>
      </a>
   </div>
   <div class="photobook-info-data-box">
      <div class="photobook-content-box">
         <div class="photobook-content-box-inner">
            <div class="photobook-content-box-wrapper">
               <p>Chiếc áo chỉ có 6 triệu nhưng phụ kiện cài áo thì có giá gấp 7 lần. Tuy nhiên vẫn không bằng việc Karik mua 2 đôi giày khác nhau và đi mỗi đôi 1 chiếc như vậy.</p>
            </div>
         </div>
      </div>
      <div class="photobook-line-bottom">
         <div class="photobook-line"><span>2sao.vn</span> | <span>Photobook</span></div>
      </div>
   </div>
</div>
