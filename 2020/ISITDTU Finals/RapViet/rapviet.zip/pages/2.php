<div class="main-photobook-content-wrapper">
   <div class="photobook-picture">
      <a title="" href="https://2sao.vietnamnetjsc.vn/images/2020/10/14/13/17/boc-gia-do-huan-luyen-vien-rap-viet-11.jpg" data-med="https://2sao.vietnamnetjsc.vn/images/2020/10/14/13/17/boc-gia-do-huan-luyen-vien-rap-viet-11.jpg" data-size="600x600" data-med-size="600x600">
         <img src="https://2sao.vietnamnetjsc.vn/images/2020/10/14/13/17/boc-gia-do-huan-luyen-vien-rap-viet-11.jpg" alt="">  
         <span class="slider-image-captions">
            <span class="slider-image-captions-inner">
               <figure>
                  <p>Còn với outfit xuất hiện ở tập 8, mọi ánh mắt đều đổ dồn vào chiếc đồng hồ mà Binz đang đeo trên tay. Mẫu phụ kiện này có kích thước 36 mm với lớp vỏ bằng vàng khối 18K và dây đeo kim loại. Giá của mẫu Patek Philippe 5036J Annual Calendar nam rapper đeo trị giá 32.000 USD.</p>
               </figure>
            </span>
         </span>
      </a>
   </div>
   <div class="photobook-info-data-box">
      <div class="photobook-content-box">
         <div class="photobook-content-box-inner">
            <div class="photobook-content-box-wrapper">
               <p>Còn với outfit xuất hiện ở tập 8, mọi ánh mắt đều đổ dồn vào chiếc đồng hồ mà Binz đang đeo trên tay. Mẫu phụ kiện này có kích thước 36 mm với lớp vỏ bằng vàng khối 18K và dây đeo kim loại. Giá của mẫu Patek Philippe 5036J Annual Calendar nam rapper đeo trị giá 32.000 USD.</p>
            </div>
         </div>
      </div>
      <div class="photobook-line-bottom">
         <div class="photobook-line"><span>2sao.vn</span> | <span>Photobook</span></div>
      </div>
   </div>
</div>
