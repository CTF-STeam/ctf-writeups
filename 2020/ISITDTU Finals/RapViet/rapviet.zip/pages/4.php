
<div class="main-photobook-content-wrapper">
   <div class="photobook-picture">
      <a title="" href="https://2sao.vietnamnetjsc.vn/images/2020/10/14/13/32/boc-gia-do-huan-luyen-vien-rap-viet-2.jpg" data-med="https://2sao.vietnamnetjsc.vn/images/2020/10/14/13/32/boc-gia-do-huan-luyen-vien-rap-viet-2.jpg" data-size="600x600" data-med-size="600x600">
         <img src="https://2sao.vietnamnetjsc.vn/images/2020/10/14/13/32/boc-gia-do-huan-luyen-vien-rap-viet-2.jpg" alt="">  
         <span class="slider-image-captions">
            <span class="slider-image-captions-inner">
               <figure>
                  <p>Set đồ khiến Karik có phần nữ tính cũng khiến dân tình hoang mang ở chiếc áo xuyên thấu có giá 7 triệu đồng.</p>
               </figure>
            </span>
         </span>
      </a>
   </div>
   <div class="photobook-info-data-box">
      <div class="photobook-content-box">
         <div class="photobook-content-box-inner">
            <div class="photobook-content-box-wrapper">
               <p>Set đồ khiến Karik có phần nữ tính cũng khiến dân tình hoang mang ở chiếc áo xuyên thấu có giá 7 triệu đồng.</p>
            </div>
         </div>
      </div>
      <div class="photobook-line-bottom">
         <div class="photobook-line"><span>2sao.vn</span> | <span>Photobook</span></div>
      </div>
   </div>
</div>
