<?php

if(isset($_GET['page']))
{
	if (!preg_match("/^[a-z0-9.]+$/", $_GET['page']))
	{
		header('Location: 404.php');
	}

	include("./pages/".$_GET['page']);
}
else
{
?>
	<h1>Tin tức RAP Việt</h1>
	<br>
	<img src="https://znews-photo.zadn.vn/w1920/Uploaded/rohunwa/2020_08_06/SUBOI8.jpg" width="1000" height="600">
<?php
}
?>



<br><br><a href="?page=1.php">1. Ở bộ trang phục được Binz mặc trong tập 7, chiếc áo thun trắng là món đồ rẻ nhất. Nhưng nhiều khán giả cho rằng áo đơn giản nhưng giá gần 500k cũng là quá mắc.</a>

<br><br><a href="?page=2.php">2. Còn với outfit xuất hiện ở tập 8, mọi ánh mắt đều đổ dồn vào chiếc đồng hồ mà Binz đang đeo trên tay. Mẫu phụ kiện này có kích thước 36 mm với lớp vỏ bằng vàng khối 18K và dây đeo kim loại. Giá của mẫu Patek Philippe 5036J Annual Calendar nam rapper đeo trị giá 32.000 USD.</a>

<br><br><a href="?page=3.php">3. Trong vòng Bứt phá, stylist của Binz chia sẻ: "Trang phục được xây dựng để bổ trợ cho đồng hồ". Quả đúng thật mẫu Jacob & Co Astronomia Solar Watch này có giá trị lên tới 281.000 USD. Khi quy đổi ra tiền Việt với 8 con số 0 khiến nhiều người hoa mắt.
</a>

<br><br><a href="?page=4.php">4. Set đồ khiến Karik có phần nữ tính cũng khiến dân tình hoang mang ở chiếc áo xuyên thấu có giá 7 triệu đồng.</a>

<br><br><a href="?page=5.php">5. Chiếc áo chỉ có 6 triệu nhưng phụ kiện cài áo thì có giá gấp 7 lần. Tuy nhiên vẫn không bằng việc Karik mua 2 đôi giày khác nhau và đi mỗi đôi 1 chiếc như vậy.</a>

<br><br><a href="?page=6.php">6. Cả một cây đồ Gucci gồm áo và quần mới bằng tiền đôi giày Jordan 1 Retro High Off-White White. Thế mới thấy đồ đi ở dưới chân chưa chắc rẻ tiền.
</a>

<br><br><a href="?page=7.php">7. Tạo hình của Karik ở tập mới nhất bị nói đùa giống nghệ sĩ Trung Dân. Nhưng ít ai biết phụ kiện nam rapper đeo của thương hiệu Chanel lên tới gần 80 triệu đồng cho dây chuyền và cài áo.
</a>

<br><br><a href="?page=8.php">8. Đắt giá nhất bộ trang phục của Wowy là sợi dây chuyền vàng 18k nặng 6 lượng, là tác phẩm nghệ thuật đương đại. Dù bao gồm dây và tượng đầu người nhưng Wowy đã cất tượng đi và chỉ đeo dây lên sân khấu. Nếu chỉ tính riêng tỷ giá về vàng thì tác phẩm này phải có giá trị tầm 350 triệu đồng.
</a>

<br><br><a href="?page=9.php">9. Đồ vật rẻ nhất nhưng lại nổi bật nhất trong set đồ chính là chiếc kính chạy chữ. Nhờ có thể thay đổi nổi dụng liên tục theo diễn biến của các vòng đấu nên khoảnh khắc nam rapper được máy quay lia tới luôn đêm lại tiếng cười và xua tan đi sức nóng của các trận đấu nảy lửa.
</a>

<br><br><a href="?page=10.php">10. Chiếc quần dài phối dây là mẫu Fear Of God Tearaway Work Pants Rust có trị giá gần 1300 đô là món đồ đắt nhất trong set trang phụ này của "danh hài" Rhymastic.
</a>

<br><br><a href="?page=11.php">11. Chiếc kính nhìn tưởng bình thường nhưng có giá tiền gồm tất cả quần áo giày cộng lại.
</a>

<br><br><a href="?page=12.php">12. Set đồ nhìn đơn giản nhất của nam producer cũng có giá hơn 50 triệu đồng.
</a>

<br><br><a href="?page=13.php">13. Dân cư mạng đùa rằng do đưa tiền cho vợ mua đồ nên trang phục của JustaTee cũng rất bình dân.
</a>

<br><br><a href="?page=14.php">14. Giọng ca "Thằng điên" diện Dawn Trucker Jacket có giá hơn 3 triệu đồng. Đây cũng là mẫu áo được nhiều fan yêu thích và tìm kiếm.</a>

